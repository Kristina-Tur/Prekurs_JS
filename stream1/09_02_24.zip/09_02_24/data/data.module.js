export const playLists = [
    {
        playListId: "1",
        playListInfo: {
            title: "Hip-hop hits",
            coverImageUrl: "cover.avif",
            totalInfo: {
                totalTrackCount: 4,
                totaltracksDurationInSec: 733
            }
        },
        tracks: [
            {
                trackId: "11",
                trackCoverImageUrl: "eminem.jpg",
                artistName: "Eminem",
                trackTitle: "Rap God",
                trackFileUrl: "eminem_-_rap_god_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: false
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
        ]
    },
    {
        playListId: "2",
        playListInfo: {
            title: "Hip-hop hits",
            coverImageUrl: "cover.avif",
            totalInfo: {
                totalTrackCount: 4,
                totaltracksDurationInSec: 733
            }
        },
        tracks: [
            {
                trackId: "11",
                trackCoverImageUrl: "eminem.jpg",
                artistName: "Eminem",
                trackTitle: "Rap God",
                trackFileUrl: "eminem_-_rap_god_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: false
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
        ]
    },
    {
        playListId: "3",
        playListInfo: {
            title: "Hip-hop hits",
            coverImageUrl: "cover.avif",
            totalInfo: {
                totalTrackCount: 4,
                totaltracksDurationInSec: 733
            }
        },
        tracks: [
            {
                trackId: "11",
                trackCoverImageUrl: "eminem.jpg",
                artistName: "Eminem",
                trackTitle: "Rap God",
                trackFileUrl: "eminem_-_rap_god_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: false
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
        ]
    },
] 