export function renderPlayLists(playListsArray) {
    debugger
    for (let i = 0; i < playListsArray.length; i++) {
        renderPlayList(playListsArray[i])
    }
}

function renderPlayList(anyPlayList) {
    const tracks = anyPlayList.tracks
    renderPlayListHeader(anyPlayList.playListInfo)
    for (let i = 0; i < tracks.length; i++) {
        renderTrack(tracks[i])
    }
}

function renderPlayListHeader(anyPlayListInfo) {
    const haederCoverElement = document.createElement("img")
    haederCoverElement.src = anyPlayListInfo.coverImageUrl
    haederCoverElement.style.width = "150px" 
    document.body.append(haederCoverElement)
    const headerTitleElement = document.createElement("h1")
    headerTitleElement.append(anyPlayListInfo.title)
    document.body.append(headerTitleElement)
}

function renderTrack(anyTrack) {
    const trackEl = document.createElement("div")
    //track cover
    const cover = document.createElement("img")
    cover.style.width = "50px"
    cover.src = anyTrack.trackCoverImageUrl
    trackEl.append(cover)
    //track description
    const trackDescriptionEl = document.createElement("h5")
    trackDescriptionEl.append(anyTrack.artistName + ": " + anyTrack.trackTitle)
     trackEl.append(trackDescriptionEl)
    //track audio
    const audio = document.createElement("audio")
    audio.src = anyTrack.trackFileUrl
    audio.controls = true
    trackEl.append(audio)

    document.body.append(trackEl)
}