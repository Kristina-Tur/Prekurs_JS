//data:
const playLists = [
    {
        playListId: "1",
        playListInfo: {
            title: "Hip-hop hits",
            coverImageUrl: "cover.avif",
            totalInfo: {
                totalTrackCount: 4,
                totaltracksDurationInSec: 733
            }
        },
        tracks: [
            {
                trackId: "11",
                trackCoverImageUrl: "eminem.jpg",
                artistName: "Eminem",
                trackTitle: "Rap God",
                trackFileUrl: "eminem_-_rap_god_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: false
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
        ]
    },
    {
        playListId: "2",
        playListInfo: {
            title: "Hip-hop hits",
            coverImageUrl: "cover.avif",
            totalInfo: {
                totalTrackCount: 4,
                totaltracksDurationInSec: 733
            }
        },
        tracks: [
            {
                trackId: "11",
                trackCoverImageUrl: "eminem.jpg",
                artistName: "Eminem",
                trackTitle: "Rap God",
                trackFileUrl: "eminem_-_rap_god_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: false
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
        ]
    },
    {
        playListId: "3",
        playListInfo: {
            title: "Hip-hop hits",
            coverImageUrl: "cover.avif",
            totalInfo: {
                totalTrackCount: 4,
                totaltracksDurationInSec: 733
            }
        },
        tracks: [
            {
                trackId: "11",
                trackCoverImageUrl: "eminem.jpg",
                artistName: "Eminem",
                trackTitle: "Rap God",
                trackFileUrl: "eminem_-_rap_god_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: false
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
            {
                trackId: "12",
                trackCoverImageUrl: "50cent.jpg",
                artistName: "50cent",
                trackTitle: "In da Club",
                trackFileUrl: "50cent_-_in_da_club_(muztune.me).mp3",
                trackDurationInSec: 1,
                isHot: true
            },
        ]
    },
] 

//render:

renderPlayLists(playLists)


function renderPlayLists(playListsArray) {
    for (let i = 0; i < playListsArray.length; i++) {
        renderPlayList(playListsArray[i])
    }
}

function renderPlayList(anyPlayList) {
    const tracks = anyPlayList.tracks
    renderPlayListHeader(anyPlayList.playListInfo)
    for (let i = 0; i < tracks.length; i++) {
        renderTrack(tracks[i])
    }
}

function renderPlayListHeader(anyPlayListInfo) {
    const haederCoverElement = document.createElement("img")
    haederCoverElement.src = anyPlayListInfo.coverImageUrl
    haederCoverElement.style.width = "150px" 
    document.body.append(haederCoverElement)
    const headerTitleElement = document.createElement("h1")
    headerTitleElement.append(anyPlayListInfo.title)
    document.body.append(headerTitleElement)
}

function renderTrack(anyTrack) {
    const trackEl = document.createElement("div")
    //track cover
    const cover = document.createElement("img")
    cover.style.width = "50px"
    cover.src = anyTrack.trackCoverImageUrl
    trackEl.append(cover)
    //track description
    const trackDescriptionEl = document.createElement("h5")
    trackDescriptionEl.append(anyTrack.artistName + ": " + anyTrack.trackTitle)
     trackEl.append(trackDescriptionEl)
    //track audio
    const audio = document.createElement("audio")
    audio.src = anyTrack.trackFileUrl
    audio.controls = true
    trackEl.append(audio)

    document.body.append(trackEl)
}















// function renderPlayList(anyPlayList) {
//     const playListIdEl = document.createElement("span")
//     playListIdEl.append("ID : " + anyPlayList.playListId)
//     document.body.append(playListIdEl)
//     renderPlayListHeader(anyPlayList.playListInfo)
//     for (let i = 0; i < anyPlayList.tracks.length; i++) {
//         renderTrack(anyPlayList.tracks[i]);
//     }
// }

// function renderPlayListHeader(anyPlayListInfo) {
//     const playListTitleEl = document.createElement("h1");
//     playListTitleEl.append(anyPlayListInfo.title);
//     document.body.append(playListTitleEl);

//     const playListCoverEl = document.createElement("img");
//     playListCoverEl.src = anyPlayListInfo.coverImageUrl;
//     playListCoverEl.style.width = "150px";
//     playListCoverEl.style.height = "150px";
//     document.body.append(playListCoverEl)

//     const playListTotalTrackCountEl = document.createElement("span")
//     playListTotalTrackCountEl.append("Tracks count : " + anyPlayListInfo.totalInfo.totalTrackCount)
    
//     document.body.append(playListTotalTrackCountEl)
    
// }
// function renderTrack(anyTrack) {
//     const trackEl = document.createElement("div")
//     //track cover
//     const cover = document.createElement("img")
//     cover.style.width = "50px"
//     cover.src = anyTrack.trackCoverImageUrl
//     trackEl.append(cover)
//     //track audio
//     const audio = document.createElement("audio")
//     audio.src = anyTrack.trackFileUrl
//     audio.controls = true
//     trackEl.append(audio)
//     document.body.append(trackEl)
//     //track description
//     trackEl.append(anyTrack.artistName + ": " + anyTrack.trackTitle)
// }


// for (let i = 0; i < playLists.length; i++) {
//     renderPlayList(playLists[i]);
// }


