import {playLists} from "./data/data.module.js"
import {renderPlayLists} from "./render/components/renderPlayLists/renderPlayLists.module.js";

renderPlayLists(playLists)